EntriesList = new Mongo.Collection('entries');
